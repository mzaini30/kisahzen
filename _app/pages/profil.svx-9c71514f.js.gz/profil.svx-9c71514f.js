import{S as T,i as Z,s as E,B as _,v as z,w as B,x as P,y as S,z as x,p as O,n as q,A as C,V as j,e as c,t as h,j as $,c as g,a as p,g as k,d as o,l as w,f,G as b}from"../chunks/vendor-ba00745c.js";import{B as G}from"../chunks/blog-e31c46df.js";import"../chunks/meta-44ee42b9.js";function H(d){let e,s,l,i,a,t,u,m;return{c(){e=c("h1"),s=h("Tentang Zen"),l=$(),i=c("p"),a=h("Aku adalah Zen, penulis dari blog yang sangat sederhana ini. Tujuanku menulis blog ini adalah untuk berbagi pengetahuan. Aku tau sih ada banyak pengetahuan yang tersebar di dunia ini. Oleh karena itu, aku harus mewariskannya kepada generasi setelahku."),t=$(),u=c("style"),m=h(`h1:not(.judul) {
  font-weight: 700;
  font-size: 1.5rem;
  line-height: 2rem;
  text-align: center;
}`)},l(n){e=g(n,"H1",{});var r=p(e);s=k(r,"Tentang Zen"),r.forEach(o),l=w(n),i=g(n,"P",{});var y=p(i);a=k(y,"Aku adalah Zen, penulis dari blog yang sangat sederhana ini. Tujuanku menulis blog ini adalah untuk berbagi pengetahuan. Aku tau sih ada banyak pengetahuan yang tersebar di dunia ini. Oleh karena itu, aku harus mewariskannya kepada generasi setelahku."),y.forEach(o),t=w(n),u=g(n,"STYLE",{});var v=p(u);m=k(v,`h1:not(.judul) {
  font-weight: 700;
  font-size: 1.5rem;
  line-height: 2rem;
  text-align: center;
}`),v.forEach(o)},m(n,r){f(n,e,r),b(e,s),f(n,l,r),f(n,i,r),b(i,a),f(n,t,r),f(n,u,r),b(u,m)},d(n){n&&o(e),n&&o(l),n&&o(i),n&&o(t),n&&o(u)}}}function L(d){let e,s;const l=[d[0],A];let i={$$slots:{default:[H]},$$scope:{ctx:d}};for(let a=0;a<l.length;a+=1)i=_(i,l[a]);return e=new G({props:i}),{c(){z(e.$$.fragment)},l(a){B(e.$$.fragment,a)},m(a,t){P(e,a,t),s=!0},p(a,[t]){const u=t&1?S(l,[t&1&&x(a[0]),t&0&&x(A)]):{};t&2&&(u.$$scope={dirty:t,ctx:a}),e.$set(u)},i(a){s||(O(e.$$.fragment,a),s=!0)},o(a){q(e.$$.fragment,a),s=!1},d(a){C(e,a)}}}const A={judul:"Profil Zen"};function V(d,e,s){return d.$$set=l=>{s(0,e=_(_({},e),j(l)))},e=j(e),[e]}class I extends T{constructor(e){super();Z(this,e,V,L,E,{})}}export{I as default,A as metadata};
